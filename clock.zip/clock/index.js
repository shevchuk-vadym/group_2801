import { Clock } from "./clock.js";
const clock = new Clock();
clock.init();
