`sass --watch lesson_9/sass:lesson_9/css` команда для запуска компиляции sass в css
